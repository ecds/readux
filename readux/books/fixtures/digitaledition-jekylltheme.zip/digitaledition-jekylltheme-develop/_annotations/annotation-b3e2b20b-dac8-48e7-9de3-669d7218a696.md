---
annotation_id: annotation-b3e2b20b-dac8-48e7-9de3-669d7218a696
author: sepalme
tei_target: '#highlight-b3e2b20b-dac8-48e7-9de3-669d7218a696'
target: highlight-b3e2b20b-dac8-48e7-9de3-669d7218a696
annotated_page: rdx_7sr72.p.idp873648

---
annotate