---
annotation_id: annotation-3189dfcb-e8cd-41ca-a0b8-d130c5d17f24
author: sarepal
tei_target: '#highlight-3189dfcb-e8cd-41ca-a0b8-d130c5d17f24'
target: highlight-3189dfcb-e8cd-41ca-a0b8-d130c5d17f24
annotated_page: rdx_7sr72.p.idp873648

---
sarepal was here