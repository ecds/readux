---
annotation_id: annotation-541aab34-fb9f-42b1-9f6c-4bf9417bd2e0
author: sepalme
tei_target: '#highlight-541aab34-fb9f-42b1-9f6c-4bf9417bd2e0'
target: highlight-541aab34-fb9f-42b1-9f6c-4bf9417bd2e0
annotated_page: rdx_7sr72.p.idp946768

---
super sara likes multiple authors