---
annotation_id: annotation-5f6ccb2e-d940-43a8-9369-9d3087db75cf
author: rsk
tei_target: '#highlight-5f6ccb2e-d940-43a8-9369-9d3087db75cf'
target: highlight-5f6ccb2e-d940-43a8-9369-9d3087db75cf
annotated_page: rdx_7sr72.p.idp356752

---
whoa!