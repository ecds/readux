---
annotation_id: annotation-86e0a8db-8ec3-4199-bc07-afc217fcb3b1
author: SaraPalmer
tei_target: '#highlight-86e0a8db-8ec3-4199-bc07-afc217fcb3b1'
target: highlight-86e0a8db-8ec3-4199-bc07-afc217fcb3b1
annotated_page: rdx_7sr72.p.idp504976

---
FB Sara