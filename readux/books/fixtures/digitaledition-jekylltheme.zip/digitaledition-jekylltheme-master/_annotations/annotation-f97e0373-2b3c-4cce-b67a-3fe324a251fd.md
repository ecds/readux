---
annotation_id: annotation-f97e0373-2b3c-4cce-b67a-3fe324a251fd
author: sarepal
tei_target: '#highlight-f97e0373-2b3c-4cce-b67a-3fe324a251fd'
target: highlight-f97e0373-2b3c-4cce-b67a-3fe324a251fd
annotated_page: rdx_7sr72.p.idp946768

---
sarepal says hey there